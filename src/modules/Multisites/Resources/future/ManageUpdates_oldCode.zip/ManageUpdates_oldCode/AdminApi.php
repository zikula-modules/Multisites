<?php

class Multisites_Api_Admin extends Zikula_AbstractApi
{
    /**
     * Gets the number of sites that require actualization for a given module
     *
     * @param Module name
     *
     * @return The number of sites
     */
    public function getNumberOfSites($args)
    {
        $modulename = FormUtil::getPassedValue('modulename', isset($args['modulename']) ? $args['modulename'] : null, 'POST');
        $currentVersion = FormUtil::getPassedValue('currentVersion', isset($args['currentVersion']) ? $args['currentVersion'] : null, 'POST');

        $table = DBUtil::getTables();
        $c = $table['multisitessitemodules_column'];
        $where = "$c[modulename] = '$modulename' AND $c[moduleversion] < '$currentVersion'";
        $numberOfItems = DBUtil::selectObjectCount('multisitessitemodules', $where);
        if ($numberOfItems === false) {
            return LogUtil::registerError($this->__f('Error! Getting number of sites where the module <strong>%s</strong> need to be upgraded.', $modulename ,$dom));
        }
        return $numberOfItems;
    }

    /**
     * Gets the sites ids where upgrading is needed
     *
     * @param Module name
     *
     * @return The number of sites
     */
    public function getSitesThatNeedUpgrade($args)
    {
        $modulename = FormUtil::getPassedValue('modulename', isset($args['modulename']) ? $args['modulename'] : null, 'POST');
        $currentVersion = FormUtil::getPassedValue('currentVersion', isset($args['currentVersion']) ? $args['currentVersion'] : null, 'POST');
        $table = DBUtil::getTables();
        $c = $table['multisitessitemodules_column'];
        $where = "$c[modulename] = '$modulename' AND $c[moduleversion] < $currentVersion";
        $sites = DBUtil::selectObjectArray('multisitessitemodules', $where);
        if ($sites === false) {
            return LogUtil::registerError($this->__f('Error! Getting sites where the module <strong>%s</strong> need to be upgraded.', $modulename ,$dom));
        }
        return $sites;
    }
}
