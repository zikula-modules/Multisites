<?php

class Multisites_Controller_Admin extends Zikula_AbstractController
{
    /**
     * Show the list of modules than can be actualized
     * @author: Albert Pérez Monfort (aperezm@xtec.cat)
     * @return: The list of available modules
     */
    public function actualizer()
    {
        // get all the modules located in modules folder
        $modules = ModUtil::apiFunc('Extensions', 'admin', 'getfilemodules');
        sort($modules);
        // checks if any module needs actualization for any site
        $i = 0;
        $upgradeNeeded = false;
        foreach($modules as $module){
            // get the number of sites which have an old version
            $numberOfSites = ModUtil::apiFunc('Multisites', 'admin', 'getNumberOfSites',
                                               array('modulename' => $module['name'],
                                                     'currentVersion' => $module['version']));
            if($numberOfSites > 0){
                $upgradeNeeded = true;
            }
            $modules[$i]['numberOfSites'] = $numberOfSites;
            $i++;
        }
        $this->view->assign('modules', $modules)
                   ->assign('upgradeNeeded', $upgradeNeeded);
        return $this->view->fetch('Multisites_admin_actualizer.tpl');
    }

    /**
     * Actualize the selected module
     * @author: Albert Pérez Monfort (aperezm@xtec.cat)
     * @param: an array with the modules that needs actualization
     * @return: The list of available modules
     */
    public function actualizeModule($args)
    {
        $modulename = isset($args['modulename']) ? $args['modulename'] : $this->request->query->get('modulename', null);

        if ($modulename == null) {
            return LogUtil::registerError($this->__('Error! Could not do what you wanted. Please check your input.'));
        }
        // get all the modules located in modules folder
        $modules = ModUtil::apiFunc('Extensions', 'admin', 'getfilemodules');
        // get the module current version
        foreach($modules as $module){
            if($module['name'] == $modulename){
                $moduleSelected = $module;
                break;
            }
        }
        $currentVersion = $moduleSelected['version'];
        // get the sites that need upgrade
        $sites = ModUtil::apiFunc('Multisites', 'admin', 'getSitesThatNeedUpgrade',
                                   array('modulename' => $modulename,
                                         'currentVersion' => $currentVersion));
        if (!$sites) {
            LogUtil::registerError($this->__f('Error! No sites could be found that needs an upgrade of module <strong>%s</strong>.', $modulename));
            return $this->redirect(ModUtil::url($this->name, 'admin', 'actualizer'));
        }

        print_r($sites);die();
    }
}
