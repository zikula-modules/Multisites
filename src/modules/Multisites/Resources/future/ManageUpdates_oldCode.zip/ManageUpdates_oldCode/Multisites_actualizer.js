
/*
function actualize()
{
    var modulesString = '';
    for (var i=0;i<document.forms['actualize'].elements.length;i++) {
        var e = document.forms['actualize'].elements[i];
        if (e.type == 'checkbox' && e.checked) {
            var modulesString = modulesString + e.name + '|';
        }
    }
    if(modulesString == '') {
        alert(notModulesSelected);
        return;
    }
    var pars = 'module=Multisites&func=actualize&modules=' + modulesString;
    //$('theme_' + themeName).update('<img src="images/ajax/circle-ball-dark-antialiased.gif">');
    var myAjax = new Zikula.Ajax.Request('ajax.php',
    {
        method: 'post',
        parameters: pars, 
        onComplete: actualize_response,
        onFailure: actualize_failure
    });
}

function actualize_response(req)
{
    // show error if necessary
    if (req.status != 200 ) { 
        pnshowajaxerror(req.responseText);
        return;
    }
    var json = pndejsonize(req.responseText);
    Element.update('content', json.content);
    if (json.stop != 1) {
        var pars = 'module=Multisites&func=actualize&modules=' + json.modules + '&id=' + json.id;
        var myAjax = new Zikula.Ajax.Request('ajax.php', {
            method: 'post',
            parameters: pars,
            onComplete: actualize_response
        });
    }
}

*/
